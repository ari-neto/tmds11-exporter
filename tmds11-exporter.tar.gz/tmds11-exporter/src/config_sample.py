# TRENDMICRO
# DEEP SECURITY
DS_HOST = "<name or ip>"
DS_PORT = 4119
DS_USER = "<user_name - base64 encoded >"
DS_PASS = "<password - base64 encoded>"
DS_IGNORE_VERIFY_SSL = True
DS_API_CHECK = 60  # in seconds

# HTTP_SERVER
SERVER_PORT = 9090

# LOGGING: NOTSET, INFO, WARN, DEBUG, ERROR, CRITICAL
LOG_LEVEL = 'INFO'

